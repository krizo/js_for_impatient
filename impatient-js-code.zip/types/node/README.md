# Readme

Custom version of `@types/node` that supports assert.strict:

* Search for `@rauschma` in `index.d.ts`
