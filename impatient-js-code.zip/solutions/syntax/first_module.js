// We export a function so that the test can import it
export function hello(x) {
  return 'Hello ' + x + '!';
}
