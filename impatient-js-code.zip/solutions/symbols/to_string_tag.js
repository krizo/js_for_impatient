export const SPECIAL_OBJECT = {
  [Symbol.toStringTag]: 'Hello',
};