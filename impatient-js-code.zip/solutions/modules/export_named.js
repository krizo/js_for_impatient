export function func() {
    return 'hello';
}