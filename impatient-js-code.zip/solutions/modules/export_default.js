export default function func() {
    return 'hello';
}