export function updateName(obj, name) {
  return {...obj, name};
}